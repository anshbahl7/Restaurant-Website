let namasteBtn = document.querySelector('button');
namasteBtn.addEventListener('click', inputMsg);

function inputMsg(){
   let name=alert('pno.-67783546372');
   
    
}